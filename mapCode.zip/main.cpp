#ifdef __cplusplus
    #include <cstdlib>
#else
    #include <stdlib.h>
#endif

#include <SDL/SDL.h>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class tile
{
    public:
    tile()
    {
        tileSet=0;
        mat=0;
        code=0;
        passable=true;
        cover=false;
    }
    int red;
    int blue;
    int green;
    int tileSet;
    int mat;
    int code;
    bool passable;
    bool cover;
};
class color
{
    public:
    color(){};
    int r,b,g;
};

bool match(int curt, int test)
{
    const int rock =130;
    const int path =100;
    const int wall = 60;
    const int water= 50;
    const int grass=  0;
    const int bridgeWide=101;
    const int bridgeTall=102;
    switch(curt)
    {
        case water: if((test==water)||(test==bridgeTall)||(test==bridgeWide))
                        return true;
                    break;
        case path: if((test==path)||(test==bridgeTall)||(test==bridgeWide))
                        return true;
                    break;
        case wall: if(test==wall)
                        return true;
                    break;
        default:    return false;
                    break;
    }
    return false;

}

int main ( int argc, char** argv )
{
    int i;
    FILE* f = fopen("testBMP.bmp", "rb");

    if(f == NULL)
        throw "Argument Exception";

    unsigned char info[54];
    fread(info, sizeof(unsigned char), 54, f); // read the 54-byte header

    // extract image height and width from header
    int width = *(int*)&info[18];
    int height = *(int*)&info[22];

    int row_padded = (width*3 + 3) & (~3);
    unsigned char* data = new unsigned char[row_padded];
    unsigned char tmp;

    vector<int> colorVec;
    for(int i = 0; i < height; i++)
    {
        fread(data, sizeof(unsigned char), row_padded, f);
        for(int j = 0; j < width*3; j += 3)
        {
            tmp = data[j];
            data[j] = data[j+2];
            data[j+2] = tmp;
            colorVec.push_back((int)data[j]);
            colorVec.push_back((int)data[j+1]);
            colorVec.push_back((int)data[j+2]);
        }
    }
    fclose(f);

    //Make a vector matrix holding all red values for the BMP
    std::vector<std::vector<color> > colorMap;
    std::vector<color> tempVec;
    color tempColor;
    int j=0;
    for(int n=0; n<height; n++)
    {
        for(int m=0; m<width; m++)
        {
            tempColor.r=colorVec.at(j);
            tempColor.g=colorVec.at(j+1);
            tempColor.b=colorVec.at(j+2);
            tempVec.push_back(tempColor);
            j+=3;
        }
        colorMap.insert(colorMap.begin(),tempVec);
        tempVec.clear();
    }

    //MAKE A VECTOR MATRIX OF THE CLASS TILE
    std::vector< std::vector<tile> > Map;
    std::vector< tile > tempTileVec;
    tile tempTile;
    for(int n=0; n<height; n++)
    {
        for(int m=0; m<width; m++)
            tempTileVec.push_back(tempTile);
        Map.push_back(tempTileVec);
        tempTileVec.clear();
    }

    bool up,down,left,right=false;
    int rock =130;
    int path =100;
    int wall = 60;
    int water= 50;
    int grass=  0;
    int bridgeWide=101;
    int bridgeTall=102;
    int curt;
    j=0;
    for(int y=0; y<height; y++)
    {
        for(int x=0; x<width; x++)
        {
            up=false;
            down=false;
            left=false;
            right=false;
            curt=colorMap.at(y).at(x).r;

            if((x>0)&&(match(curt, colorMap.at(y).at(x-1).r)))
                {left=true;}
            if((x<width-1)&&(match(curt, colorMap.at(y).at(x+1).r)))
                {right=true;}
            if((y>0)&&(match(curt, colorMap.at(y-1).at(x).r)))
                {up=true;}
            if((y<height-1)&&(match(curt, colorMap.at(y+1).at(x).r)))
                {down=true;}

            if(up)
            {   if(left)
                {   if(right)
                    {   if(down)
                            Map.at(y).at(x).code=0;
                        else
                            Map.at(y).at(x).code=1; }
                    else
                    {   if(down)
                            Map.at(y).at(x).code=2;
                        else
                            Map.at(y).at(x).code=3; }    }
                else
                {   if(right)
                    {   if(down)
                            Map.at(y).at(x).code=4;
                        else
                            Map.at(y).at(x).code=5; }
                    else
                    {   if(down)
                            Map.at(y).at(x).code=6;
                        else
                            Map.at(y).at(x).code=7; }   }   }
            else
            {   if(left)
                {   if(right)
                    {   if(down)
                            Map.at(y).at(x).code=8;
                        else
                            Map.at(y).at(x).code=9; }
                    else
                    {   if(down)
                            Map.at(y).at(x).code=10;
                        else
                            Map.at(y).at(x).code=11; }   }
                else
                {   if(right)
                    {   if(down)
                            Map.at(y).at(x).code=12;
                        else
                            Map.at(y).at(x).code=13; }
                    else
                    {   if(down)
                            Map.at(y).at(x).code=14;
                        else
                            Map.at(y).at(x).code=0; }   }   }
            if(curt==grass)
            {
                Map.at(y).at(x).mat=0;
                Map.at(y).at(x).code=0;
                Map.at(y).at(x).passable=false;
                Map.at(y).at(x).cover=false;
            }
            if(curt==rock)
            {
                Map.at(y).at(x).mat=0;
                Map.at(y).at(x).code=1;
                Map.at(y).at(x).passable=true;
                Map.at(y).at(x).cover=true;
            }
            if(curt==path)
            {
                Map.at(y).at(x).mat=1;
                Map.at(y).at(x).passable=false;
                Map.at(y).at(x).cover=false;
            }
            if(curt==wall)
            {
                Map.at(y).at(x).mat=2;
                Map.at(y).at(x).passable=true;
                Map.at(y).at(x).cover=true;
            }
            if(curt==water)
            {
                Map.at(y).at(x).mat=3;
                Map.at(y).at(x).passable=true;
                Map.at(y).at(x).cover=false;
            }
            if(curt==bridgeWide)
            {
                Map.at(y).at(x).mat=0;
                Map.at(y).at(x).code=3;
                Map.at(y).at(x).passable=false;
                Map.at(y).at(x).cover=false;
            }
            if(curt==bridgeTall)
            {
                Map.at(y).at(x).mat=0;
                Map.at(y).at(x).code=2;
                Map.at(y).at(x).passable=false;
                Map.at(y).at(x).cover=false;
            }
            Map.at(y).at(x).red=colorMap.at(y).at(x).r;
            Map.at(y).at(x).green=colorMap.at(y).at(x).g;
            Map.at(y).at(x).blue=colorMap.at(y).at(x).b;
        }
    }

    // initialize SDL video
    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "Unable to init SDL: %s\n", SDL_GetError() );
        return 1;
    }

    // make sure SDL cleans up before exit
    atexit(SDL_Quit);

    // create a new window
    SDL_Surface* screen = SDL_SetVideoMode(width*20, height*20, 16,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF);
    if ( !screen )
    {
        printf("Unable to set 640x480 video: %s\n", SDL_GetError());
        return 1;
    }

    // load an image
    SDL_Surface* tileSet = SDL_LoadBMP("tileSet1.bmp");
    if (!tileSet)
    {
        printf("Unable to load bitmap: %s\n", SDL_GetError());
        return 1;
    }



    // program main loop
    bool done = false;
    while (!done)
    {
        // message processing loop
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            // check for messages
            switch (event.type)
            {
                // exit if the window is closed
            case SDL_QUIT:
                done = true;
                break;

                // check for keypresses
            case SDL_KEYDOWN:
                {
                    // exit if ESCAPE is pressed
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        done = true;
                    break;
                }
            } // end switch
        } // end of message processing

        // DRAWING STARTS HERE

        // clear screen
        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 0, 0));
        SDL_Rect copi={0,0,20,20};
        SDL_Rect past={0,0,20,20};
        for(int y=0; y<Map.size(); y++)
            for(int x=0; x<Map.at(y).size(); x++)
            {
                switch(Map.at(y).at(x).code)
                {
                case 0: copi.x=0; copi.y=0;break;
                case 1: copi.x=1; copi.y=0;break;
                case 2: copi.x=2; copi.y=0;break;
                case 3: copi.x=0; copi.y=1;break;
                case 4: copi.x=1; copi.y=1;break;
                case 5: copi.x=2; copi.y=1;break;
                case 6: copi.x=0; copi.y=2;break;
                case 7: copi.x=1; copi.y=2;break;
                case 8: copi.x=2; copi.y=2;break;
                case 9: copi.x=0; copi.y=3;break;
                case 10:copi.x=1; copi.y=3;break;
                case 11:copi.x=2; copi.y=3;break;
                case 12:copi.x=0; copi.y=4;break;
                case 13:copi.x=1; copi.y=4;break;
                case 14:copi.x=2; copi.y=4;break;
                default:copi.x=2; copi.y=2;
                }
                copi.x = copi.x * 20;
                copi.y = copi.y * 20;
                copi.x=copi.x+(Map.at(y).at(x).mat*60);
                past.x=x*20; past.y=y*20;
                SDL_BlitSurface(tileSet, &copi, screen, &past);

            }
            SDL_Rect fillbox={0,0,20,20};

            for(int n=0; n>colorVec.size(); n+=3)
            {
                SDL_FillRect(screen, &fillbox, SDL_MapRGB(screen->format, colorVec.at(n), colorVec.at(n+1), colorVec.at(n+2)));
                fillbox.x+=20;
                if(fillbox.x>=width*20 )
                {
                    fillbox.x=0;
                    fillbox.y+=20;
                }
            }


        // DRAWING ENDS HERE

        // finally, update the screen :)
        SDL_Flip(screen);
    } // end main loop
    vector<vector<tile> > outMap;
    vector<tile> mapCol;
    for(int x=0; x<width; x++)
    {
        for(int y=0; y<height; y++)
        {
            mapCol.push_back(Map.at(y).at(x));
        }
        outMap.push_back(mapCol);
        mapCol.clear();
    }

    ofstream file;
    file.open("mapCode.txt");
    file<<width<<" "<<height<<endl;
    for(int x=0; x<width; x++)
    {
        for(int y=0; y<height; y++)
        {
            file<<outMap.at(x).at(y).mat<<" ";

            file<<outMap.at(x).at(y).code<<" ";
                if(outMap.at(x).at(y).code<10)
                    file<<" ";

            file<<outMap.at(x).at(y).passable<<" ";

            file<<outMap.at(x).at(y).cover<<" ";

            file<<outMap.at(x).at(y).red<<" ";
                if(outMap.at(x).at(y).red<100)
                    file<<" ";
                if(outMap.at(x).at(y).red<10)
                    file<<" ";
            file<<outMap.at(x).at(y).green<<" ";
                if(outMap.at(x).at(y).green<100)
                    file<<" ";
                if(outMap.at(x).at(y).green<10)
                    file<<" ";
            file<<outMap.at(x).at(y).blue<<" ";
                if(outMap.at(x).at(y).blue<100)
                    file<<" ";
                if(outMap.at(x).at(y).blue<10)
                    file<<" ";
        }
        file<<endl;
    }
    file.close();
    // free loaded bitmap
    SDL_FreeSurface(tileSet);

    // all is well ;)*/
    printf("Exited cleanly\n");
    return 0;
}
